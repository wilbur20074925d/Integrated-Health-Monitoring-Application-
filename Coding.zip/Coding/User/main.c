#include <stm32f10x.h>
#include "delay.h"
#include "led.h"
#include "key_s.h"
#include "oled_iic.h"
#include "buzzer.h"
#include "rtc.h" 
#include "timer.h"
#include "ds18b20.h"
#include "usart.h"	
#include "stmflash.h"
#include "ADXL345.h"
#include "esp8266.h"

//Flash���籣�����ݲ���
#define LEN  50//�������ݸ���(���λ����ΪCRC)
u16 eep[LEN];
#define hrMax eep[0]
#define hrMin eep[1]
#define stepMax eep[2]
#define tmpMax eep[3]
#define tmpMin eep[4]

#define DIS_NUM 3//����3������
#define DIS_DEFAUL 0
#define DIS_PARA 1
#define DIS_RTC 2

#define SAMP_NUM 4

#define STEP_EEP eep[5]

u8 disCtrl = DIS_DEFAUL;
u8 setRTC = 0;
u8 setPara = 0;
u8 tmp;//�¶�
u8 hr_buf[5];
u8 hr_dis;//����ֵ
void readFlash(void);
void writeFlash(void);
void revAPP(void);
void sendAPP(void);
void sortBubbing(u8* _buf,u8 _len)
{
    u8 i,j,temp;
    for(i = 0 ; i <_len-1; i++)
    {
        //��i�˱Ƚ�
        for(j = 0 ; j <_len-i-1; j++)
        {
            //��ʼ���бȽϣ����arr[j]��arr[j+1]��ֵ���Ǿͽ���λ��
            if(_buf[j] > _buf[j+1])
            {
                temp = _buf[j];
                _buf[j] = _buf[j+1];
                _buf[j+1] = temp;
            }
        }

    }    
}
int main(void)
{
    u8 cnt;
    u8 key;
    u8 refresh = 1;
    u8 col,page;   
    u8 alarm_tmp=0;
    u8 alarm_hr=0;
    u8 alarm_step=0;
    u8 enable_step=1;
    u8 enable_hr = 1;
    u8 hr_trig_last=0;
    u8 clr_cnt=0;
//    u8 i;
//    u8  i;	
//	u8 record_f = 0;
    
    char temp;
    LED_Init();
    delay_Init(72);
    MY_NVIC_PriorityGroupConfig(2);
    uart_init(72,9600);
    KEY_Init();
    OLED_Init();
    Buzzer_Init();
    TIM_Cap_PA11_Init();
    DS18B20_Init();
        
    printf("USART1 send [OK]\r\n");
    esp8266_init();
    ADXL345_Init();
    while(ADXL345_Check())
    {
		OLED_Print_F12(0,0,"ADXL345 [err]");
        LED = !LED;
        Beep(200);
		delay_ms(500);         
    }
	while(RTC_Init())
	{		
		OLED_Print_F12(0,0,"RTC init [err]");
        LED = !LED;
        Beep(200);
		delay_ms(500);        
	}
      
    readFlash();
    OLED_Clear();
    Beep(200);
    while(1)
    {
        delay_ms(1);
        cnt++;
        revAPP();
        if(cnt>200)
        {
            cnt = 0;
            LED = !LED;
            sendAPP();
            SetBeep(0);
            clr_cnt++;
            if(clr_cnt>10)
            {
                hr_dis = 0;
                hr_trig = 0;
            }             
            tmp = DS18B20_Get_Temp()/10;
            refresh = 1;
            if(enable_step)
            {
                if(ADXL345_Step_Count())
                {
                    Beep(50);
                    STEP_EEP = ADXL345_step;
                    writeFlash();
                }                
            }
            else
            {
                ADXL345_step = 0;
            }
                              
            if((setPara|setRTC)==0)
            {
                if(tmp<tmpMin||tmp>tmpMax)
                {
                    if(alarm_tmp==0)alarm_tmp = 2;
                }
                else
                {
                    alarm_tmp = 0;
                }
                
                if(enable_step&&ADXL345_step>=stepMax)
                {
                    if(alarm_step==0)alarm_step = 2;
                }
                else
                {
                    alarm_step = 0;
                }

            }
            if(alarm_tmp==2)SetBeep(LED);
            if(alarm_step==2)SetBeep(LED);
            if(alarm_hr==2)SetBeep(LED);
        }
        if(hr_trig_last != hr_trig)
        {            
            clr_cnt = 0;
            
//            col = 8*6+24;
//            col += (hr_trig*6);
//            OLED_ShowChar(col,page,hr_dis%10+'.',FZ12);
            
            if(hr_trig<SAMP_NUM)
            {
                hr_buf[hr_trig] = heartRate;
            }
            else
            {
                
//                col = 8*6+24;
//                col += (hr_trig*6);
//                for(i=0;i<4;i++)
//                col = OLED_ShowChar(col,page,hr_dis%10+' ',FZ12);                
                
                
                sortBubbing(hr_buf,SAMP_NUM);
                //i = 1;
				
                hr_dis = hr_buf[SAMP_NUM/2];
				
                hr_trig = 0;
                //record_f = 1;
                
                alarm_hr =0;
                if(enable_hr)
				{
					if(hr_dis > hrMax || hr_dis < hrMin)
					{
						if(alarm_hr==0)alarm_hr = 2;
					}
                }
                else
                {
                    alarm_hr=0;
                }
                
            }
            
            hr_trig_last = hr_trig;
            refresh = 1;
        }
        key = KeyScan(1);
        if(key)
        {
            Beep(200);
            refresh = 1;
            LED = 0;
            if(alarm_tmp)alarm_tmp = 1;
            if(alarm_hr)alarm_hr = 1;
            if(alarm_step)alarm_step = 1;
            if(key==0x01)
            {
                if((setPara|setRTC)==0)//�л�����
                {
                    disCtrl++;
                    if(disCtrl>=DIS_NUM)disCtrl = 0;
                    OLED_Clear();                    
                }
                else
                {
                    if(setPara)
                    {
                        setPara++;
                        if(setPara>5)
                        {
                            setPara=0;
                            writeFlash();
                        }
                    }
                    else if(setRTC)
                    {
                        setRTC++;
                        if(setRTC>6)
                        {
                            setRTC = 0;
                            RTC_Set((u16)calendar.w_year,calendar.w_month,\
                            calendar.w_date,calendar.hour,calendar.min,calendar.sec);                    
                        }                        
                    }
                }

            }
            else if(key==0xF1)
            {
                Beep(200);
                if(disCtrl==DIS_RTC)
                {
                    if(setRTC==0)setRTC++;
                    else setRTC = 0;
                }
                else if(disCtrl==DIS_PARA)
                {
                    if(setPara==0)setPara++;
                    else setPara = 0;
                }
            }
            else if(key==2)//+
            {
                if(setRTC)
                {
                    if(setRTC==1)calendar.w_year++;
                    if(setRTC==2){if(calendar.w_month<12)calendar.w_month++;else calendar.w_month=1;}
                    if(setRTC==3){if(calendar.w_date<31)calendar.w_date++; else calendar.w_date = 1;}
                    if(setRTC==4){if(calendar.hour<23)calendar.hour++; else calendar.hour=0;}
                    if(setRTC==5){if(calendar.min<59)calendar.min++;else calendar.min=0;}
                    if(setRTC==6){if(calendar.sec<59)calendar.sec++;else calendar.sec=0;}
                }
                else if(setPara)
                {
                    if(setPara==1){if(stepMax<999)stepMax++;}
                    else if(setPara==2){if(tmpMin<100)tmpMin++;}
                    else if(setPara==3){if(tmpMax<100)tmpMax++;}
                    else if(setPara==4){if(hrMin<200)hrMin++;}
                    else if(setPara==5){if(hrMax<200)hrMax++;}                    
                }
                else 
                {
                    if(enable_hr)enable_hr=0;
                    else enable_hr = 1;
                }
                
            }
            else if(key==0xF2)
            {
                if(setPara)
                {
                    if(setPara==1){if(stepMax<999)stepMax+=10;}
                    else if(setPara==2){if(tmpMin<100)tmpMin+=10;}
                    else if(setPara==3){if(tmpMax<100)tmpMax+=10;}
                    else if(setPara==4){if(hrMin<200)hrMin+=10;}
                    else if(setPara==5){if(hrMax<200)hrMax+=10;}                    
                }                
            }
            else if(key==3) //-           
            { 
                if(setRTC)
                {
                    if(setRTC==1)if(calendar.w_year>2000)calendar.w_year--;
                    if(setRTC==2){if(calendar.w_month>1)calendar.w_month--;else calendar.w_month=12;}
                    if(setRTC==3){if(calendar.w_date>1)calendar.w_date--;else calendar.w_date=31; }
                    if(setRTC==4){if(calendar.hour)calendar.hour--; else calendar.hour=23;}
                    if(setRTC==5){if(calendar.min)calendar.min--;else calendar.min=59;}
                    if(setRTC==6){if(calendar.sec)calendar.sec--;else calendar.sec=59;}
                }
                else if(setPara)
                {
                    if(setPara==1){if(stepMax>1)stepMax--;}
                    else if(setPara==2){if(tmpMin>1)tmpMin--;}
                    else if(setPara==3){if(tmpMax>1)tmpMax--;}                    
                    else if(setPara==4){if(hrMin>1)hrMin--;}
                    else if(setPara==5){if(hrMax>1)hrMax--;}
                } 
                else
                {
                    if(enable_step)enable_step=0;
                    else enable_step= 1;
                }
            }
            else if(key==0xF3)
            {
                if(setPara)
                {
                    if(setPara==1){if(stepMax>10)stepMax-=10;}
                    else if(setPara==2){if(tmpMin>10)tmpMin-=10;}
                    else if(setPara==3){if(tmpMax>10)tmpMax-=10;}                    
                    else if(setPara==4){if(hrMin>10)hrMin-=10;}
                    else if(setPara==5){if(hrMax>10)hrMax-=10;}
                }                
            }
            else if(key==4)
            {
                ADXL345_step = 0;
                STEP_EEP = 0;
                writeFlash();                
                hr_dis = 0;
                if(alarm_step)alarm_step = 0;
            }
            
        }
        if(refresh)
        {
            refresh = 0;
            if(disCtrl == DIS_DEFAUL)
            {
                OLED_Print_F12(0,0,"    [�����ֻ�]");
                col = 0;page = 2;
                col = OLED_ShowString(col,page,"20",FZ8);
                col = OLED_ShowChar(col,page,calendar.w_year/10%10+'0',FZ8);
                col = OLED_ShowChar(col,page,calendar.w_year%10+'0',FZ8);
                col = OLED_ShowChar(col,page,'/',FZ8);
                col = OLED_ShowChar(col,page,calendar.w_month/10%10+'0',FZ8);
                col = OLED_ShowChar(col,page,calendar.w_month%10+'0',FZ8);
                col = OLED_ShowChar(col,page,'/',FZ8);
                col = OLED_ShowChar(col,page,calendar.w_date/10%10+'0',FZ8);
                col = OLED_ShowChar(col,page,calendar.w_date%10+'0',FZ8);
                col = OLED_ShowChar(col,page,' ',FZ8);
                col = OLED_ShowChar(col,page,' ',FZ8);                
                col = OLED_ShowChar(col,page,calendar.hour/10%10+'0',FZ8);
                col = OLED_ShowChar(col,page,calendar.hour%10+'0',FZ8);
                col = OLED_ShowChar(col,page,':',FZ8);
                col = OLED_ShowChar(col,page,calendar.min/10%10+'0',FZ8);
                col = OLED_ShowChar(col,page,calendar.min%10+'0',FZ8);
                col = OLED_ShowChar(col,page,':',FZ8);
                col = OLED_ShowChar(col,page,calendar.sec/10%10+'0',FZ8);
                col = OLED_ShowChar(col,page,calendar.sec%10+'0',FZ8); 

                col = 0;page = 4;
                if(alarm_step&&LED)col = OLED_Print_F12(col,page,"����:");else
                col = OLED_Print_F12(col,page,"����:");
                if(enable_step)
                {
                col = OLED_ShowChar(col,page,ADXL345_step/100%10+'0',FZ12);
                col = OLED_ShowChar(col,page,ADXL345_step/10%10+'0',FZ12); 
                col = OLED_ShowChar(col,page,ADXL345_step/1%10+'0',FZ12);                    
                }else
                {
                    col = OLED_ShowString(col,page,"---",FZ12);
                }

                col = OLED_Print_F12(col,page,"  ");        
                if(alarm_tmp&&LED)col = OLED_Print_F12(col,page,"����:");else
                col = OLED_Print_F12(col,page,"����:");
                col = OLED_ShowChar(col,page,tmp/10%10+'0',FZ12);
                col = OLED_ShowChar(col,page,tmp%10+'0',FZ12);
                col = OLED_Print_F12(col,page,"c");
                
                col = 0;page = 6; 
                if(alarm_hr&&LED)col = OLED_Print_F12(col,page,"����:");else
                col = OLED_Print_F12(col,page,"����:");
                if(enable_hr)
                {                 
                    col = OLED_ShowChar(col,page,hr_dis/100%10+'0',FZ12);
                    col = OLED_ShowChar(col,page,hr_dis/10%10+'0',FZ12);
                    col = OLED_ShowChar(col,page,hr_dis%10+'0',FZ12);                   
				}
                else
                {
                    col = OLED_ShowString(col,page,"---",FZ12);
                    
                } 
                col = OLED_Print_F12(col,page,"b/m");                
            }
            else if(disCtrl == DIS_PARA)
            {
                OLED_Print_F12(0,0,"    [��������]");
                col = 0;page = 2;
                col = OLED_Print_F12(col,page,"����->[");
                col = OLED_ShowChar(col,page,',',FZ12);
                col = OLED_ShowChar(col,page,stepMax/100%10+'0',FZ12);
                col = OLED_ShowChar(col,page,stepMax/10%10+'0',FZ12);if(setPara==1&&LED)temp = ('_');else
                temp = stepMax%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12); 
                col = OLED_ShowChar(col,page,']',FZ12); 
                
                col = 0;page = 4;
                col = OLED_Print_F12(col,page,"����->[");
                col = OLED_ShowChar(col,page,tmpMin/10%10+'0',FZ12);if(setPara==2&&LED)temp = ('_');else
                temp = tmpMin%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12); 
                col = OLED_ShowChar(col,page,',',FZ12);
                col = OLED_ShowChar(col,page,tmpMax/10%10+'0',FZ12);if(setPara==3&&LED)temp = ('_');else
                temp = tmpMax%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12); 
                col = OLED_ShowChar(col,page,']',FZ12); 
                
                col = 0;page = 6;
                col = OLED_Print_F12(col,page,"����->[");
                col = OLED_ShowChar(col,page,hrMin/10%10+'0',FZ12);if(setPara==4&&LED)temp = ('_');else
                temp = hrMin%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12); 
                col = OLED_ShowChar(col,page,',',FZ12);
                col = OLED_ShowChar(col,page,hrMax/100%10+'0',FZ12);
                col = OLED_ShowChar(col,page,hrMax/10%10+'0',FZ12);if(setPara==5&&LED)temp = ('_');else
                temp = hrMax%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12); 
                col = OLED_ShowChar(col,page,']',FZ12);                 
            }
            else if(disCtrl == DIS_RTC)
            {
                OLED_Print_F12(0,0,"    [ʱ������]");
                col = 0;page = 2;
                col = OLED_ShowString(col,page,"20",FZ12);
                col = OLED_ShowChar(col,page,calendar.w_year/10%10+'0',FZ12);if(setRTC==1&&LED)temp = ('_');else
                temp = calendar.w_year%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12);
                col = OLED_ShowChar(col,page,'/',FZ12);
                col = OLED_ShowChar(col,page,calendar.w_month/10%10+'0',FZ12);if(setRTC==2&&LED)temp = ('_');else
                temp = calendar.w_month%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12);
                col = OLED_ShowChar(col,page,'/',FZ12);
                col = OLED_ShowChar(col,page,calendar.w_date/10%10+'0',FZ12);if(setRTC==3&&LED)temp = ('_');else
                temp = calendar.w_date%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12);
                col = OLED_ShowChar(col,page,' ',FZ12);
                col = OLED_ShowChar(col,page,' ',FZ12);
                switch (calendar.week)
                {
                    case 1:
                        OLED_ShowString(col,page,"Mon.",FZ12);
                        break;
                    case 2:
                        OLED_ShowString(col,page,"Tue.",FZ12);
                        break;
                    case 3:
                        OLED_ShowString(col,page,"Wed.",FZ12);
                        break;
                    case 4:
                        OLED_ShowString(col,page,"Thu.",FZ12);
                        break;
                    case 5:
                        OLED_ShowString(col,page,"Fri.",FZ12);
                        break;
                    case 6:
                        OLED_ShowString(col,page,"Sat.",FZ12);
                        break;
                    case 0:
                        OLED_ShowString(col,page,"Sun.",FZ12);
                        break;
                    default:
                        OLED_ShowString(col,page,"Err.",FZ12);
                        break;
                }                
                col = 0;page = 4;
                col = OLED_ShowChar(col,page,calendar.hour/10%10+'0',FZ12);if(setRTC==4&&LED)temp = ('_');else
                temp = calendar.hour%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12);
                col = OLED_ShowChar(col,page,':',FZ12);
                col = OLED_ShowChar(col,page,calendar.min/10%10+'0',FZ12);if(setRTC==5&&LED)temp = ('_');else
                temp = calendar.min%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12);
                col = OLED_ShowChar(col,page,':',FZ12);
                col = OLED_ShowChar(col,page,calendar.sec/10%10+'0',FZ12);if(setRTC==6&&LED)temp = ('_');else
                temp = calendar.sec%10+'0';
                col = OLED_ShowChar(col,page,temp,FZ12);                
            }
            else
            {
                OLED_Print_F12(0,0,"default interface");
            }
        }
        
        
    }     
}


void writeFlash(void)
{
    Flash_Write(eep,LEN);
}

void readFlash(void)
{
    if(0==Flash_Read(eep,LEN))
    {
        ADXL345_step = STEP_EEP;
    }
    else
    {
        stepMax = 10;
        tmpMin = 15;
        tmpMax = 39;
        hrMax = 100;
        hrMin = 50;
    }
}

////////////////////////////////////////////////////////////////////
void sendAPP(void)
{
    static u8 step=0;
    static u8 psc=0;
    char str1[20],str2[20],str3[20];
    
	//��Ƶִ�У����ͷ����ٶ�
	psc++;
	if(psc < 5)return;
	else psc = 0;
 

    if(step== 0)APPsendLable0("����","����","����","","","");
    else if(step== 3)APPsendLable1("step:","Tmin","Tmax","HRmin","HRmax","","","");
    else if(step==6)APPsendLable2("","","","");
    else if(step==9)APPsendTitle("�����ֻ�");
    else
    {
        //ADXL345_step ,tmp ,heartRate
        sprintf(str1,"%d",ADXL345_step);
        sprintf(str2,"%d",tmp);
        sprintf(str3,"%d",heartRate);
        APPsendValue(str1,str2,str3,"","","");
    }
    step++;
    if(step>10)step=0;
}



void revAPP(void)
{
    if(revPara_F)
    {
        revPara_F=0;
        Beep(200);
        
        //tmpH = revDate[0];
        //tmpL = revDate[1];
        if(revDate[0])
        stepMax= revDate[0]; 
        
		if(revDate[1])
        tmpMin = revDate[1]; 
		
		if(revDate[2])
		tmpMax = revDate[2]; 
		
		if(revDate[3])
        hrMin = revDate[3]; 
		
		if(revDate[4])
		hrMax = revDate[4]; 
	
    }
    
    if(revLED_F&0x80)
    {
        Beep(200);
        if(revLED_F&0x01)
        {
            Beep(200);
        }

        
        revLED_F = 0;            
    }    
}

