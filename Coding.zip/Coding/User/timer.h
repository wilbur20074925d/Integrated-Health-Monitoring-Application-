#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"

extern u8 heartRate;   
extern u8 hr_trig;

void TIM_Cap_PA11_Init(void);
#endif























