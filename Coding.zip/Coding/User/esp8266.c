#include "esp8266.h"
#include "delay.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "oled_iic.h"
#ifdef ESP8266

//�� ԭ�ַ�����(_srcStr) �в��� �Ӽ�(_subStr)
//0xEE-δ�鵽,����-���ؿ�ʼƥ��ƫ����
//ע�⣺�����ַ���Сд
//Ҫ�����ַ������� < 200�ֽ�
u8 SearchStr(char *_srcStr,char*_subStr)
{
    u8 i=0,j=0;
    u8 matchIdx = 0;
    u8 tempChar;
   

	if(_subStr[0]=='\0')return 0;//�ռ����κμ��ϵ��Ӽ�
    while(_srcStr[i] != '\0')
    {
        //���Դ�Сд, ȫ��ת��Ϊ��д
        if(_srcStr[i]>='a'&&_srcStr[i]<='z')_srcStr[i] -= ('a' - 'A');
        else tempChar = _subStr[j];
        	
		if(_srcStr[i] != tempChar)
		{
			matchIdx ++;//�ƶ�ƥ��λ��
			i = matchIdx;//Դ�ַ�����ƥ��λ�ÿ�ʼ
		}
		else
		{
			i++;
			j++;
			if(_subStr[j] == '\0')
            {
                //printf("= %d \r\n",matchIdx);
                return matchIdx;//ƥ�����
            }
            
		}		
    }
    //printf("= 0xEE \r\n");
    return 0xEE; //ƥ��ʧ��(238)   
}

//0-�ɹ���1-ʧ��
//ATcmd :���͵�����
//ack   :Ӧ��ָ��
//tryTimes:���Դ���
u8 try_AT(char* ATcmd,u8 tryNum)
{
    u8 try_cnt = 0;   

    while(try_cnt < tryNum)
    {
        cliBufClr();
		serialPrint(ATcmd);                   
        delay_ms(200);
		if(0xEE != SearchStr(cliBuf,"OK"))return 0;
        try_cnt++;
    }
    return 1;
}

//��ʼ��esp8266
//0-�ɹ�����0-ʧ��
u8  ESP8266_configAP(void)
{ 
    if(try_AT("AT+RST\r\n",10))return 1;
	delay_ms(200);
    if(try_AT("AT+CWMODE=2\r\n",10))return 2;
	delay_ms(200);
    if(try_AT("AT+RST\r\n",10))return 3;
    delay_ms(200);
    if(try_AT("AT+CWSAP=\"ESP8266_xiaoyu\",\"0123456789\",11,4\r\n",10))return 4;
    delay_ms(200);
    if(try_AT("AT+CIPMUX=1\r\n",10))return 5;
    delay_ms(200);
    if(try_AT("AT+CIPSERVER=1,5000\r\n",10))return 6;
	delay_ms(200);
    if(try_AT("AT+CIPSTO=0\r\n",10))return 7;	
	delay_ms(200);
    if(try_AT("AT+CIPAP=\"192.168.1.110\"\r\n",10))return 8;
    delay_ms(200);
	return 0;  
}

//0-�ɹ���1-ʧ��
u8 ESP8266_TXmsg(char* str)
{
    u8 i=0;
    char len=0;
	char *a =str;
  
	//���㷢���ַ�������
	while(*a!='\0')
	{
		len++;
		a++;
		//���Ʒ��ͳ���
        if(len>50)len = 50;
	} 
	    
	cliBufClr();
    serialPrint("AT+CIPSEND=0,");
	Send_Char_Com(len/10%10+'0');
	Send_Char_Com(len%10+'0');
	serialPrint("\r\n");
	
    delay_ms(100);
//    if(0xEE != SearchStr(cliBuf,"link is not valid"))return 1;
//    if(0xEE != SearchStr(cliBuf,"ERROR"))return 2;
	if(0xEE != SearchStr(cliBuf,"OK"))
    {            
        for(i=0;i<len;i++)
        { 
            Send_Char_Com(*str++);
        }
        serialPrint("\r\n");
        return 0;
    }
	
    return 3;
}  
#endif
void esp8266_init(void)
{
#ifdef ESP8266    
    //��ʼ��esp8266
    u8 err_code = 0;
	OLED_Print_F12(0,0,"wifi config...");
//    char str[]="0123456789abcdef";
//    LCD_GotoXY(0,0);
//    LCD_Print("wifi config...");
//    LCD_GotoXY(0,1);
//    LCD_Print("wait for seconds");    
	err_code = ESP8266_configAP();
//    LCD_Clear();
//    LCD_GotoXY(0,0);
    if(err_code)
    {
		//sprintf(str,"setWifi [err%d]",err_code);
		//LCD_Print(str);   
		OLED_Print_F12(0,0,"ESP8266 [err] ");			
    }
    else
    {
        //LCD_Print("set wifi [ok]"); 
		OLED_Print_F12(0,0,"ESP8266 [ok ] ");		
    }
    delay_ms(500); 
#endif    
}


