#ifndef __ESP8266_H
#define __ESP8266_H 			   
#include "sys.h" 
#include "usart.h"	


//extern char SSID[30];//wifi����
//extern char Password[30];//��¼����
//extern char IPaddr[20];//IP��ַ
//extern char PortID[10];//�˿ں�



u8 ESP8266_TXmsg(char* str);
void esp8266_init(void);

#endif




