/*--------------------------------------------------------------------------
LCD1602液晶驱动程序

+----------------------------------------------------+
|                      LCD1602                       |
|                                                    |
|  1   2   3   4   5   6   7   8   9 ...  14  15  16 |
+--+---+---+---+---+---+---+---+---+--...-+---+---+--+
  VSS VDD  V0  RS  RW  EN  D0  D1  D2 ... D7  A   K
  GND VCC  |   PB0 GND PB1 NC. NC. NC.   PB15 VCC GND
         __|__
   VCC--|_____|--GND

LCD1602显存分布：
  0x00 0x01 0x02 0x03 ...0x09 0x0A 0x0B 0x0C 0x0D 0x0E 0x0F
  0x40 0x41 0x42 0x43 ...0x49 0x4A 0x4B 0x4C 0x0D 0x0E 0x0F

LCD1602坐标分布：
  x= 0 1 2 3 4 5 6 7 8 9 A B C D E F
     X X X X X X X X X X X X X X X X  y = 1
     X X X X X X X X X X X X X X X X  y = 1

V2.2
(1)加入显示汉字"元"
(2)完善了RW接口直接拉低，4线驱动方式


Copyright (c) 2020-2030 Quan's technology, Inc.
All rights reserved.
--------------------------------------------------------------------------*/
#ifndef __LCD1602_PIN4_H
#define __LCD1602_PIN4_H	 
#include "sys.h"
#include "delay.h"


#define lcd1602_RS PBout(9) 
#define lcd1602_EN PBout(8)

#define lcd1602_D4 PBout(12)
#define lcd1602_D5 PBout(13)
#define lcd1602_D6 PBout(14)
#define lcd1602_D7 PBout(15)

//如果使用自定义符号，则定义以下宏
#define myICON

//定义滚屏显示函数
//#define DIS_SCROLL

void LCD_Init(void);//LCD初始化
void LCD_Clear(void);//清屏

void LCD_GotoXY(u8 _X,u8 _Y);//插入光标位置(默认隐藏)
void LCD_Cursor(unsigned char show); //设置光标(闪烁1/隐藏0)
void LCD_WrDat(unsigned char dat);//写入单个字符
void LCD_WrNUM(unsigned char dat);//写入单个数据
void LCD_Print(char *str);//写入字符串
void LCD_WrHex(unsigned char _hex);//写入十六进制数据F5(0xf5)


//滚屏显示
void LCD_Scroll_L(void);
void LCD_Scroll_R(void);
//自定义字符
void Dis_YUAN(void);
void Dis_SheShiDu(void);
void Dis_TmpLogo(void);
void Dis_HumLog(void); 
void Dis_XXDZ(void);

void Display_Coin(void);//请投纸币


#endif


