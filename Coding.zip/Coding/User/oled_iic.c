#include "oled_iic.h"
#include "font_ascii.h"
#include "font_hz12x12.h"

static unsigned char DRAM[24] = {0};

void OLED_IIC_Start(void)
{
	OLED_SCLK_Set();
	OLED_SDIN_Set();
	OLED_SDIN_Clr();
	OLED_SCLK_Clr();
}
void OLED_IIC_Wait_Ack(void)
{
	OLED_SCLK_Set();
	OLED_SCLK_Clr();
}
void OLED_IIC_Stop(void)
{
	OLED_SCLK_Set();
	OLED_SDIN_Clr();
	OLED_SDIN_Set();	
}

void Write_IIC_Byte(unsigned char IIC_Byte)
{
	unsigned char i;
	unsigned char m,da;
	da=IIC_Byte;
	OLED_SCLK_Clr();
	for(i=0;i<8;i++)		
	{
		m=da;
		//	OLED_SCLK_Clr();
		m=m&0x80;
		if(m==0x80)
		{OLED_SDIN_Set();}
		else OLED_SDIN_Clr();
		da=da<<1;
		OLED_SCLK_Set();
		OLED_SCLK_Clr();
	}
}
void Write_IIC_Data(unsigned char IIC_Data)
{
	OLED_IIC_Start();
	Write_IIC_Byte(0x78);			//D/C#=0; R/W#=0
	OLED_IIC_Wait_Ack();	
	Write_IIC_Byte(0x40);			//write data
	OLED_IIC_Wait_Ack();	
	Write_IIC_Byte(IIC_Data);
	OLED_IIC_Wait_Ack();	
	OLED_IIC_Stop();
}
void Write_IIC_Command(unsigned char IIC_Command)
{
	OLED_IIC_Start();
	Write_IIC_Byte(0x78);//Slave address,SA0=0
	OLED_IIC_Wait_Ack();	
	Write_IIC_Byte(0x00);//write command
	OLED_IIC_Wait_Ack();	
	Write_IIC_Byte(IIC_Command); 
}
void OLED_WR_Byte(unsigned char dat,unsigned char cmd)
{
	if(cmd)
	{
		Write_IIC_Data(dat);
	}
	else {
		Write_IIC_Command(dat);
	}
}

//��ʼ��SSD1306					    
void OLED_Init(void)
{ 	
	GPIO_Config(OLED_SCK_PORT,OLED_SCK_PIN,OUTPUT_DOWN);
    GPIO_Config(OLED_SDA_PORT,OLED_SDA_PIN,OUTPUT_DOWN);

	delay_ms(800);
	OLED_WR_Byte(0xAE,OLED_CMD);//--display off
	OLED_WR_Byte(0x00,OLED_CMD);//---set low column address
	OLED_WR_Byte(0x10,OLED_CMD);//---set high column address
	OLED_WR_Byte(0x40,OLED_CMD);//--set start line address  
	OLED_WR_Byte(0xB0,OLED_CMD);//--set page address
	OLED_WR_Byte(0x81,OLED_CMD); // contract control
	OLED_WR_Byte(0xFF,OLED_CMD);//--128   
	OLED_WR_Byte(0xA1,OLED_CMD);//set segment remap 
	OLED_WR_Byte(0xA6,OLED_CMD);//--normal / reverse
	OLED_WR_Byte(0xA8,OLED_CMD);//--set multiplex ratio(1 to 64)
	OLED_WR_Byte(0x3F,OLED_CMD);//--1/32 duty
	OLED_WR_Byte(0xC8,OLED_CMD);//Com scan direction
	OLED_WR_Byte(0xD3,OLED_CMD);//-set display offset
	OLED_WR_Byte(0x00,OLED_CMD);//
	
	OLED_WR_Byte(0xDA,OLED_CMD);//set com pin configuartion
	OLED_WR_Byte(0x12,OLED_CMD);//
	
	OLED_WR_Byte(0xDB,OLED_CMD);//set Vcomh
	OLED_WR_Byte(0x30,OLED_CMD);//
	
	OLED_WR_Byte(0x8D,OLED_CMD);//set charge pump enable
	OLED_WR_Byte(0x14,OLED_CMD);//
	
	OLED_WR_Byte(0xAF,OLED_CMD);//--turn on oled panel
    
    OLED_Clear();
}  
//==========================================================================
//��������
//col  ~ [0,127]
//page ~ [0,7]
void OLED_Set_Pos(unsigned char col, unsigned char page) 
{ 	OLED_WR_Byte(0xb0+page,OLED_CMD);
	OLED_WR_Byte(((col&0xf0)>>4)|0x10,OLED_CMD);
	OLED_WR_Byte((col&0x0f),OLED_CMD); 
}   	  
//����OLED��ʾ    
void OLED_Display_On(void)
{
	OLED_WR_Byte(0X8D,OLED_CMD);  //SET DCDC����
	OLED_WR_Byte(0X14,OLED_CMD);  //DCDC ON
	OLED_WR_Byte(0XAF,OLED_CMD);  //DISPLAY ON
}
//�ر�OLED��ʾ     
void OLED_Display_Off(void)
{
	OLED_WR_Byte(0X8D,OLED_CMD);  //SET DCDC����
	OLED_WR_Byte(0X10,OLED_CMD);  //DCDC OFF
	OLED_WR_Byte(0XAE,OLED_CMD);  //DISPLAY OFF
}		   			 
//��������,������,������Ļ�Ǻ�ɫ��!��û����һ��!!!	  
void OLED_Clear(void)  
{  
	unsigned char i,n;		    
	for(i=0;i<8;i++)  
	{  
		OLED_WR_Byte (0xb0+i,OLED_CMD);    //����ҳ��ַ��0~7��
		OLED_WR_Byte (0x00,OLED_CMD);      //������ʾλ�á��е͵�ַ
		OLED_WR_Byte (0x10,OLED_CMD);      //������ʾλ�á��иߵ�ַ   
		for(n=0;n<64;n++)OLED_WR_Byte(0,OLED_DATA); 
	} //������ʾ
}

//��ָ��λ����ʾһ���ַ�,���������ַ�
//x:0~127
//y:0~7				 
//size:ѡ������ 16/12 
unsigned char OLED_ShowChar(unsigned char col,unsigned char page,char _char,FZ_e Char_Size)
{      	
	unsigned char c=0,i=0;
    if(_char >= ' ')
        c = _char - ' ';//�õ�ƫ�ƺ��ֵ
    else return col;
    
	if(col > (Max_Column - 6) ){col = 0; page = page + 2;}
	if(Char_Size == FZ12)//Font[8*12]
	{
        //����ʾ���ݿ�����DRAM
        for(i=0;i<16;i++)
        {
            DRAM[i] = F8X12[c][i];
        }
        //�Դ�����������1λ
        for(i=0;i<8;i++)
        {
            DRAM[i*2+1] <<= 1;
            if(DRAM[i*2]&0x80)DRAM[i*2+1] |= 0x01;
            DRAM[i*2] <<= 1;
        }		
        
        //д��OLED
        OLED_Set_Pos(col,page);	
		for(i=0;i<8;i++)
        {
            OLED_WR_Byte(DRAM[i*2],OLED_DATA);
        }
		OLED_Set_Pos(col,page+1);
		for(i=0;i<8;i++)
        {
            OLED_WR_Byte(DRAM[i*2+1],OLED_DATA);
        }
        col += 8;
	}
	else//Font[6X8] 
    {	
		OLED_Set_Pos(col,page);
		for(i=0;i<6;i++)
		OLED_WR_Byte(F6x8[c][i],OLED_DATA);
        col +=6;
	}
    return col;
}

//��ʾһ���ַ��Ŵ�
unsigned char OLED_ShowString(unsigned char col,unsigned char page,char *_str,FZ_e Char_Size)
{
	unsigned char j = 0,offset = 6;
    if(Char_Size==FZ12)offset = 8;
	while (_str[j] != '\0')
	{		
		OLED_ShowChar(col,page,_str[j],Char_Size);
        col += offset;
		if(col > (Max_Column-6)){col=0; page+=2;}
		j++;
	}
    return col;
}

//m^n����
u32 mypow(unsigned char m,unsigned char n)
{
	u32 result=1;	 
	while(n--)result*=m;    
	return result;
}

//��ʾn������
//col,page: �������	 
//len :���ֵ�λ��
//size:�����С
//num:��ֵ(0~4294967295);
//����룬��ʾ����
unsigned char OLED_ShowNumber(unsigned char col,unsigned char page,u32 _num,unsigned char len,FZ_e size)
{         	
	unsigned char t,temp;
	unsigned char enshow=0;
    unsigned char offset;
    if(size==FZ12)offset = 8;
    else offset = 6;
	for(t=0;t<len;t++)
	{
		temp = (_num/mypow(10,len-t-1))%10;
		if(enshow==0 && t<(len-1))
		{
			if(temp==0)
			{
				OLED_ShowChar(col,page,' ',size);
                col += offset;
				continue;
			}
            else 
            {
                enshow=1; 
            }
		}
	 	OLED_ShowChar(col,page,temp+'0',size);
        col += offset;    
	}
    return col;
}


//��ʾ��������
void LCD_HanZi12x12(unsigned char _X,unsigned char _Y,unsigned char *_HanZi)
{
	unsigned char indx,i;
    
	if(*_HanZi<0x7f)return;//�Ǻ��ֱ��룬ֱ���˳�
    
    if(_X > (128-12))return;//X�ᳬ��
    if(_Y > (64-12))return;//Y�ᳬ��

	//�����ֿ⣬���Һ��ֶ�Ӧ��ģ
	for(indx=0;indx<HZ_LEN;indx++)
	{
		if((*_HanZi==zpix_HZinfo[indx].pCode[0])&&(*(_HanZi+1)==zpix_HZinfo[indx].pCode[1]))
		{
			break;
		}
	}
	
	//���޴���
	if(indx>=HZ_LEN)
    {
        return;
    }

    //����ʾ���ݿ�����DRAM
    for(i=0;i<24;i++)
    {
        DRAM[i] = zpix_HZinfo[indx].pData[i];
    }
    //�Դ�����������1λ������������������2���أ�����������3����
    for(i=0;i<12;i++)
    {
        DRAM[i+12] <<= 1;
        if(DRAM[i]&0x80)DRAM[i+12] |= 0x01;
        DRAM[i] <<= 1;
    }
	//��ʾ����
	OLED_Set_Pos(_X,_Y);
	for(i=0;i<12;i++)
	{
		//OLED_WR_Byte(zpix_HZinfo[indx].pData[i],OLED_DATA);
        OLED_WR_Byte(DRAM[i],OLED_DATA);
	}
	OLED_Set_Pos(_X,_Y+1);
	for(i=0;i<12;i++)
	{
		//OLED_WR_Byte(zpix_HZinfo[indx].pData[i+12],OLED_DATA);
        OLED_WR_Byte(DRAM[i+12],OLED_DATA);
	}
    
}

//��ʾ�������
unsigned char OLED_Print_F12(unsigned char col,unsigned char page,char *_str)
{

	while(*_str != '\0')
	{
		if(*_str<0x7f)//�ַ�
		{
            OLED_ShowChar(col,page,*_str,FZ12);           
            _str += 1;//��һ���ַ�
			col += 8;
		}
		else//����
		{
			LCD_HanZi12x12(col,page,(unsigned char*)_str);
			_str += 2;//��һ������
			col += 12;
		}
	}
    return (col);
}


