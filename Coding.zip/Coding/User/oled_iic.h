/*
OLED12864�Դ�ֲ���
col=0~127
+--+--+--+--+-...-+--+--+--+ page=0
+--+--+--+--+-...-+--+--+--+ page=1
+--+--+--+--+-...-+--+--+--+ page=2
+--+--+--+--+-...-+--+--+--+ page=3
+--+--+--+--+-...-+--+--+--+ page=4
+--+--+--+--+-...-+--+--+--+ page=5
+--+--+--+--+-...-+--+--+--+ page=6
+--+--+--+--+-...-+--+--+--+ page=7
*/
#ifndef __OLED_IIC_H
#define __OLED_IIC_H			  	 
#include "sys.h"
#include "delay.h"
#include "stdlib.h"	


//-----------------OLED IIC�˿ڶ���---------------- 
#define OLED_SCK_PORT GPIOB
#define OLED_SCK_PIN  GPIO_Pin_12
#define OLED_SDA_PORT GPIOB
#define OLED_SDA_PIN  GPIO_Pin_13

 	

//-------------------------------------------------------------------------------
#define OLED_SCLK_Clr() GPIO_ResetBits(OLED_SCK_PORT,OLED_SCK_PIN)//SCL
#define OLED_SCLK_Set() GPIO_SetBits(OLED_SCK_PORT,OLED_SCK_PIN)

#define OLED_SDIN_Clr() GPIO_ResetBits(OLED_SDA_PORT,OLED_SDA_PIN)//SDA
#define OLED_SDIN_Set() GPIO_SetBits(OLED_SDA_PORT,OLED_SDA_PIN)

typedef enum
{ 
    FZ8 = 8,
    FZ12 = 12
}FZ_e;

#define OLED_MODE 0
#define SIZE 8
#define XLevelL		0x00
#define XLevelH		0x10
#define Max_Column	128
#define Max_Row		64
#define	Brightness	0xFF 
#define X_WIDTH 	128
#define Y_WIDTH 	64	    						  
		     
#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����



//��������
void OLED_Init(void);
void OLED_Clear(void);
unsigned char OLED_ShowChar(unsigned char col,unsigned char page,char _char,FZ_e Char_Size);
unsigned char OLED_ShowString(unsigned char col,unsigned char page,char *_str,FZ_e Char_Size);
unsigned char OLED_ShowNumber(unsigned char col,unsigned char page,u32 _num,unsigned char len,FZ_e size);

unsigned char OLED_Print_F12(unsigned char col,unsigned char page,char *_str);

#endif

