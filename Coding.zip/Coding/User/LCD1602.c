/*--------------------------------------------------------------------------
LCD1602液晶驱动程序

+----------------------------------------------------+
|                      LCD1602                       |
|                                                    |
|  1   2   3   4   5   6   7   8   9 ...  14  15  16 |
+--+---+---+---+---+---+---+---+---+--...-+---+---+--+
  VSS VDD  V0  RS  RW  EN  D0  D1  D2 ... D7  A   K
  GND VCC  |   PB0 GND PB1 NC. NC. NC.   PB15 VCC GND
         __|__
   VCC--|_____|--GND

LCD1602显存分布：
  0x00 0x01 0x02 0x03 ...0x09 0x0A 0x0B 0x0C 0x0D 0x0E 0x0F
  0x40 0x41 0x42 0x43 ...0x49 0x4A 0x4B 0x4C 0x0D 0x0E 0x0F

LCD1602坐标分布：
  x= 0 1 2 3 4 5 6 7 8 9 A B C D E F
     X X X X X X X X X X X X X X X X  y = 1
     X X X X X X X X X X X X X X X X  y = 1

V2.2
(1)加入显示汉字"元"
(2)完善了RW接口直接拉低，4线驱动方式


Copyright (c) 2020-2030 Quan's technology, Inc.
All rights reserved.
--------------------------------------------------------------------------*/
#include "sys.h"
#include "delay.h"  
#include "lcd1602.h"

#define COMMAND  0
#define DATA	 1
   
void LCD_Write(unsigned char cmd,unsigned char isData)
{
    delay_us(2000); //Hardcoding delay, keep waiting while the LCD is busy
        
    lcd1602_RS = isData;	
    lcd1602_EN = 0;
  
    if(cmd&0x80)lcd1602_D7=1;else lcd1602_D7=0;  
    if(cmd&0x40)lcd1602_D6=1;else lcd1602_D6=0;
    if(cmd&0x20)lcd1602_D5=1;else lcd1602_D5=0;
    if(cmd&0x10)lcd1602_D4=1;else lcd1602_D4=0;
    delay_us(2);
    lcd1602_EN=1;
    delay_us(2);
    lcd1602_EN=0;
    
    if(cmd&0x08)lcd1602_D7=1;else lcd1602_D7=0;
    if(cmd&0x04)lcd1602_D6=1;else lcd1602_D6=0;
    if(cmd&0x02)lcd1602_D5=1;else lcd1602_D5=0;
    if(cmd&0x01)lcd1602_D4=1;else lcd1602_D4=0; 
    delay_us(2);
    lcd1602_EN=1;
	delay_us(2);
    lcd1602_EN=0;
}
void LCD_WrCmd(unsigned char dat)
{
	LCD_Write(dat,COMMAND);
}
void LCD_WrDat(unsigned char dat)
{
	LCD_Write(dat,DATA);
}  
void LCD_WrNUM(unsigned char dat)
{
	LCD_WrDat(dat+'0');	
}

void LCD_GotoXY(unsigned char _X,unsigned char _Y)
{
	unsigned char temp;
	if(_Y)temp=0xC0+(_X&0x0F);
	else temp=0x80+(_X&0x0F);
	LCD_WrCmd(temp);
}

//闪烁show=1
//隐藏show=0
void LCD_Cursor(unsigned char show)	
{						
	if(show)
		LCD_WrCmd(0x0f);//光标显示
	else
		LCD_WrCmd(0x0c);//光标隐藏
}

void LCD_Print(char *Pwdata)
{	
	while(*Pwdata != '\0')
		LCD_WrDat(*Pwdata++); 
}

void LCD_Clear(void)
{
   	LCD_WrCmd(0x01);//清显示
}

void LCD_WrHex(unsigned char _hex)
{
	char temp;
    
	temp=_hex>>4;
	if(temp<10){temp=temp+'0';}
	else temp=temp-10+'A';
	LCD_WrDat(temp);
    
	temp=_hex&0x0F;
	if(temp<10){temp=temp+'0';}
	else temp=temp-10+'A';
	LCD_WrDat(temp);	
}
#ifdef DIS_SCROLL
//向左滚屏显示
void LCD_Scroll_L(void)
{
    LCD_WrCmd(0x18);
}
//向右滚屏显示
void LCD_Scroll_R(void)
{
    LCD_WrCmd(0x1c);
}
#endif


#ifdef myICON
const unsigned char _yuan[8] = {//元
0x00,0x1F,0x00,0x1F,0x0A,0x0A,0x13,0x00
};
const unsigned char _sheShiDu[8] = {//`c
0x10,0x07,0x08,0x08,0x08,0x08,0x07,0x00
};
const unsigned char _temp[8] = {//温度标识
0x04,0x06,0x04,0x06,0x04,0x0A,0x0E,0x00
};
const unsigned char _humi[8] = {//湿度标识
0x01,0x04,0x0E,0x1F,0x04,0x14,0x08,0x00
};
const unsigned char _XIAO[8] = {//小
0x04,0x04,0x04,0x15,0x15,0x15,0x04,0x0C
};
const unsigned char _YU[8] = {//鱼
0x04,0x0A,0x11,0x15,0x11,0x0a,0x04,0x0A
};
const unsigned char _DIAN[8] = {//电
0x04,0x1F,0x15,0x1F,0x15,0x1f,0x04,0x07
};
const unsigned char _DI[8] = {//子
0x1f,0x01,0x02,0x04,0x1f,0x04,0x04,0x1C
};

void Dis_YUAN(void)
{
	LCD_WrDat(0x00);
}
void Dis_SheShiDu(void)
{
	LCD_WrDat(0x01);
}
void Dis_TmpLogo(void)
{
	LCD_WrDat(0x02);
}
void Dis_HumLog(void)
{
	LCD_WrDat(0x03);
}
void Dis_XXDZ(void)
{
	LCD_WrDat(0x04);
    LCD_WrDat(0x05);
    LCD_WrDat(0x06);
    LCD_WrDat(0x07);  
}
#endif

void LCD_Init(void)
{ 
#ifdef myICON    
	u8 i;
#endif
    
    RCC->APB2ENR |= 1<<3;//使能PORTB时钟	

	GPIOB->CRH &= 0X0000FFFF;
	GPIOB->CRH |= 0X33330000;//PB12-15推挽输出  	 
	GPIOB->ODR |= 0XFF000000; 

	GPIOB->CRH &= 0XFFFFFF00;//PB8、9推挽输出 
	GPIOB->CRH |= 0X00000033;	
	GPIOB->ODR |= (1<<8|1<<9);
	
    delay_us(1000);
      	
	LCD_WrCmd(0x33);
	LCD_WrCmd(0x32);
	LCD_WrCmd(0x28);
	LCD_WrCmd(0x0c);
    LCD_WrCmd(0x06);//写一个指针加1
	LCD_WrCmd(0x01);
	LCD_WrCmd(0x80);
    
#ifdef myICON
	LCD_WrCmd(0x40);//写入CGRAM
	for(i=0;i<8;i++)
		LCD_WrDat(_yuan[i]);
	for(i=0;i<8;i++)
		LCD_WrDat(_sheShiDu[i]);
	for(i=0;i<8;i++)
		LCD_WrDat(_temp[i]);
	for(i=0;i<8;i++)
		LCD_WrDat(_humi[i]); 

	for(i=0;i<8;i++)
		LCD_WrDat(_XIAO[i]);
	for(i=0;i<8;i++)
		LCD_WrDat(_YU[i]);
	for(i=0;i<8;i++)
		LCD_WrDat(_DIAN[i]);
	for(i=0;i<8;i++)
		LCD_WrDat(_DI[i]);
#endif

	LCD_GotoXY(0,0);
	LCD_Cursor(0);
	LCD_WrHex(0x00);	
	LCD_Print(" ");
	LCD_WrNUM(0);
	LCD_Clear();	
}
/*
//要显示的汉字编码，定义为一个数组
const unsigned char qing[32] = {//请
0x00,0x00,0x10,0x0B,0x00,0x01,0x18,0x0B,
0x00,0x00,0x08,0x1F,0x08,0x1E,0x08,0x1F,
0x09,0x09,0x09,0x09,0x0D,0x09,0x00,0x00,
0x02,0x1E,0x02,0x1E,0x02,0x06,0x00,0x00
};
const unsigned char tou[32] =  { //投
0x00,0x00,0x09,0x09,0x09,0x1D,0x0A,0x08,
0x00,0x00,0x1C,0x04,0x04,0x04,0x03,0x00,
0x0B,0x0D,0x18,0x08,0x08,0x1B,0x00,0x00,
0x1E,0x02,0x14,0x08,0x14,0x03,0x00,0x00
};
const unsigned char zhi[32] =  {//纸
0x00,0x00,0x08,0x09,0x11,0x15,0x19,0x09,
0x00,0x00,0x07,0x1C,0x04,0x04,0x04,0x1F,
0x11,0x1D,0x11,0x05,0x09,0x11,0x00,0x00,
0x04,0x04,0x04,0x0D,0x13,0x01,0x00,0x00
};
const unsigned char bi[32] =  {//币
0x00,0x00,0x00,0x1F,0x00,0x00,0x0F,0x08,
0x00,0x00,0x0F,0x10,0x10,0x10,0x1F,0x11,
0x08,0x08,0x08,0x08,0x08,0x00,0x00,0x00,
0x11,0x11,0x11,0x11,0x13,0x10,0x00,0x00
};
const unsigned char jiantou[16] =  {//->
0x00,0x00,0x00,0x10,0x08,0x04,0x02,0x01,
0x01,0x02,0x04,0x08,0x10,0x00,0x00,0x00
};

void Display_Coin()//请投纸币
{
	unsigned char i;
	//64字节的自定义CGRAM
	//能够存放8个字符
	LCD_WrCmd(0x40);//写入CGRAM
	for(i=0;i<32;i++)
		LCD_WrDat(qing[i]);
	for(i=0;i<32;i++)
		LCD_WrDat(tou[i]);
	LCD_Clear();
	LCD_GotoXY(0x0,0);//设定显示坐标
	LCD_WrDat(0x00);	 //“请”上半部
	LCD_WrDat(0x01);
	LCD_GotoXY(0x0,1);//设定显示坐标
	LCD_WrDat(0x02);	 //“请”下半部
	LCD_WrDat(0x03);
	
	LCD_GotoXY(0x2,0);//->
	LCD_WrDat(0x04);
	LCD_WrDat(0x05);
	LCD_GotoXY(0x2,1);
	LCD_WrDat(0x06);
	LCD_WrDat(0x07);
}
*/

