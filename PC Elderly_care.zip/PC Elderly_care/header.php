<div class="header navbar navbar-inverse ">
  <div class="navbar-inner">
    <div class="header-seperation" style="background-color: rgb(27,30,36);">
      <ul class="nav pull-left notifcation-center" id="main-menu-toggle-wrapper" style="display:none" >
        <li class="dropdown"> <a id="main-menu-toggle" href="#main-menu"  class="" >
          <div class="iconset top-menu-toggle-white"></div>
          </a> </li>
      </ul>
      <a href="dashboard.php" style="color:#3498db; font-size:35px; padding-top:15px;padding-left: 25px">Elderly Care </a>
    
    </div>
    <div class="header-quick-nav" style="background-color: rgb(27,30,36)">
      <div class="pull-left">
       
      
      </div>
      <div class="pull-right">
        <div class="chat-toggler">
          <div class="user-details">
            <div class="username">  <span class="bold"><?php echo $_SESSION['name'];?></span> </div>
          </div>
          <div class="iconset top-down-arrow"></div>
          </a>
          <div class="profile-pic"> <img src="assets/img/profiles/avatar_small.jpg"  alt="" data-src="assets/img/profiles/avatar_small.jpg" data-src-retina="assets/img/profiles/avatar_small2x.jpg" width="35" height="35" /> </div>
        </div>
        <ul class="nav quick-section ">
          <li class="quicklinks"> <a data-toggle="dropdown" class="dropdown-toggle  pull-right " href="#" id="user-options">
            <div class="iconset top-settings-dark "></div>
            </a>
            <ul class="dropdown-menu  pull-right" role="menu" aria-labelledby="user-options">
              <li><a href="profile.php"> My Account</a> </li>
              <li class="divider"></li>
              <li><a href="logout.php"></i>Log Out</a></li>
            </ul>
          </li>

        </ul>
      </div>
      <!-- END CHAT TOGGLER -->
    </div>
    <!-- END TOP NAVIGATION MENU -->
  </div>
  <!-- END TOP NAVIGATION BAR -->
</div>
<!-- END HEADER -->