<?php
session_start();
$con = mysqli_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

mysqli_select_db("communication", $con);

$result = mysqli_query($bd,"SELECT * FROM message  where user_email='".$_SESSION['login']."' ORDER BY id asc");


while($row = mysqli_fetch_array($result))
  {
  echo '<p>'.'<span>'.$row['sender'].'</span>'. '&nbsp;&nbsp;' . $row['message'].'</p>';
  }

mysqli_close($con);
?>
