 <!-- BEGIN SIDEBAR -->
  <div class="page-sidebar" id="main-menu">
    <!-- BEGIN MINI-PROFILE -->
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
      <div class="user-info-wrapper">
        
        <div class="user-info">
          <div class="greeting" style="font-size:24px; ">Welcome</div>
          <div class="username" style="font-size:12px; ">Admin</div>
          <div class="status" style="font-size:10px; ">Status<a href="#">
            <div class="status-icon green"></div>
            Online</a></div>
        </div>
      </div>
      <!-- END MINI-PROFILE -->
      <!-- BEGIN SIDEBAR MENU -->
      

    <ul style="margin-top: 50px">	
      <li class="start"> <a href="home.php" style="font-size: 24px"> Dashboard</span>  </a> 
		    </li>
    
          <li><a href="change-password.php" style="font-size: 20px">Change Password</a></li>
                            <li><a href="manage-users.php" style="font-size: 24px"> Normal Users</a></li>
                             <li><a href="manage-interns.php" style="font-size: 24px;color: white"> Interns </a></li>
                             <li><a href="manage-employee.php" style="font-size: 24px"> Employee</a></li>
                             <li><a href="manage-clients.php" style="font-size: 24px"> Clients </a></li>
                          <li><a href="manage-tickets.php" style="font-size: 24px"> Manage Record</a></li>
                              <li ><a href="manage-quotes.php" style="font-size: 24px"> Manage Checkup</a></li> 
                              <li><a href="manage-career.php" style="font-size: 23px"> Manage  Career</a></li>   
                            <li><a href="user-access-log.php" style="font-size: 23px">User Access Log</a></li>
                             
							    
                          
							
                           
    </ul>