
  <div class="page-sidebar" id="main-menu">
    
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
      <div class="user-info-wrapper">
        
        <div class="user-info">
          <div class="greeting" style="font-family:Comic Sans MS, Times, serif;font-size:30px; ">Welcome</div>
          <div class="username" style="font-family:Comic Sans MS, Times, serif;font-size:15px; ">Admin</div>
          <div class="status" style="font-family:Comic Sans MS, Times, serif;font-size:14px; ">Status<a href="#">
            <div class="status-icon green"></div>
            Online</a></div>
        </div>
      </div>

      

    <ul style="font-family:Comic Sans MS, Times, serif;margin-top: 50px">	
      <li class="start"> <a href="home.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px"> Dashboard</span>  </a> 
		    </li>
    
          <li><a href="change-password.php" style="font-family:Comic Sans MS;font-size: 24px">Change Password</a></li>
                            <li><a href="manage-users.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px"> Normal Users</a></li>
                             <li><a href="manage-interns.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px"> Interns </a></li>
                             <li><a href="manage-employee.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px"> Employee</a></li>
                             <li><a href="manage-clients.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px"> Clients </a></li>
                          <li><a href="manage-tickets.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px"> Manage Ticket</a></li>
                              <li ><a href="manage-quotes.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px"> Manage Quotes</a></li> 
                              <li><a href="manage-career.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px"> Manage  Career</a></li>   
                            <li><a href="user-access-log.php" style="font-family:Comic Sans MS, Times, serif;font-size: 24px;color: white">User Access Log</a></li>
                             
							    
                          
							
                           
    </ul>