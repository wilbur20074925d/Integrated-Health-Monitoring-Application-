<?php

$mysql_hostname ="localhost";
$mysql_user ="root";
$mysql_password ="";
$mysql_database ="crm1";
$prefix = "";
$bd = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect to the Oracle database");
mysqli_select_db($bd,$mysql_database) or die("Could not select the Oracle database!");

?>

